#################################################################################################
### COMP1811 - CW1 Outlook Simulator                                                          ###
###            confidential program                                                            ###
### Partner A:                                                                                ###
###            <Tahseen Taj>, SID<001464034-1>                              ###
### Partner B:                                                                                ###
###            <Samira Ozturk>, SID<00149407-4>                              ###
#################################################################################################


class Mail:
    def __init__(self, m_id, frm, to, date, subject, tag, body):
        self._m_id = m_id  # Unique ID assigned to each email
        self._frm = frm  # Sender's email address
        self._to = to  # Receiver's email address
        self._subject = subject  # Subject line of the email
        self._date = date  # Date/time email was sent or received
        self._tag = tag  # Folder tag (Inbox, Bin, Private, etc.)
        self._body = body  # Main message content

        # Additional states used by mailbox features:
        self._flag = False  # Boolean flag: marks important emails
        self._read = False  # Boolean flag: tracks if the email has been opened/read


# String representation of the mail object
# Used for pretty printing and summary display.
# f-string allow insert variables directly into strings and join them into one line.
# Example Output:
# m_id:1 from:gre@email.com to:gregre@email.com
# date: 2025-10-31 Meeting Reminder,Inbox,Read:False, Flagged: False
def __str__(self):
    return (
        f"m_id:{self.m_id}\t"
        f"from:{self.frm}\t|{self.to}\t|{self.date}|"
        f"{self.subject}|{self.tag}|Read:{self.read}|Flagged:{self.flag}"
    )


# PROPERTY GETTERS (Read-only accessors)
# These methods provide controlled access to private data.
# Prevents direct access to internal variable and mail.subject instead of mail._subject code
@property
def m_id(self):
    return self._m_id


@property
def frm(self):
    return self._frm


@property
def to(self):
    return self._to


@property
def date(self):
    return self._date


@property
def body(self):
    return self._body


@property
def subject(self):
    return self._subject


@property
def tag(self):
    return self._tag


@property
def read(self):
    return self._read


@property
def flag(self):
    return self._flag


# PROPERTY SETTERS (Controlled write access)
# These allow specific attributes to be safely modified.
# Enables controlled modification, like moving email to new folder.
# read setter updates read/unread.
# flag setter marks importance.

@tag.setter
def tag(self, value):
    # Precondition: 'value' should correspond to valid folder tag
    # (e.g., Inbox, Bin, Private, etc.)
    self._tag = value


@read.setter
def read(self, value: bool):
    # Updates read/unread status
    self._read = value


@flag.setter
def flag(self, value: bool):
    # Marks or unmarks the email as important
    self._flag = value


# FEATURE A2 display attributes, sets email read status to true.
# returns the formated string for late use.
# Opens email feature.
# show_email(): Placeholder for formatted email display
def show_email(self):
    self._read = True

    print(f"EMAIL ID: {self._m_id}")
    print(f"From:      {self._frm}")
    print(f"To:        {self._to}")
    print(f"Date:      {self._date}")
    print(f"Subject:   {self._subject}")
    print(f"Tag:       {self._tag}")
    print(f"Flagged:   {self._flag}")
    print(f"Read:      {self._read}")
    print("BODY:")
    print(self._body)

    return {
        "m_id": self._m_id,
        "from": self._frm,
        "to": self._to,
        "subject": self._subject,
        "date": self._date,
        "tag": self._tag,
        "flag": self._flag,
        "read": self._read,
        "body": self._body,
    }


# Example: testing the Mail class
from mail import Mail

mail1 = Mail(
    1,
    "gre@email.com",
    "gregre@email.com",
    "2025-10-31",
    "Meeting Reminder",
    "Inbox",
    "Hi Gre, meeting at 17:00."
)
mail1.show_email()
#################################################################################################
### COMP1811 - CW1 Outlook Simulator                                                          ###
###            confidential program                                                            ###
### Partner A:                                                                                ###
###            <Tahseen Taj>, SID<001464034-1>                              ###
### Partner B:                                                                                ###
###            <Samira Ozturk>, SID<00149407-4>                              ###
#################################################################################################


import word_count
from cgitb import text

from mail import Mail  # use the mail class from mail.py file
class Confidential(Mail):
    def __init__(self, m_id, frm, to, date, subject, tag, body):
        super().__init__(m_id, frm, to, date, subject, tag, body)
        # inherits attributes fromparent class
        self.body = self.encrypt(body)
        # replaces the body with an encrypted version

    # FA.5b
    def encrypt(self, text):
        words = text.split()  # breaks message into list of words
        word_count = len(words)  # counts how many words
        if word_count == 0
        word_count == 1

    encrypted_text = ""  # Start wirh empty encrypted text
    # if character is a letter
    for ch in text:  # goes through each character in text
        if ch.isalpha():  # checks if character conta8ns only letters
            # converts characters ro lowercase
            lower_ch = ch.lower()
            # get position in alphabet
            position = ord(lower_ch) - 96
            # -96 reverse order so a=1 not a=96
            encrypted_value = position * word_count
            encrypted_text += str(encrypted_value)
        elif ch.isdigit():  # checks if character contains only digits
            # turn 1 to a, 2 to b ect.
            integer = int(ch)
            letter_equivalent = chr(integer + 96)
            encrypted_text += letter_equivalent
            # chr turns number to character
        else:
                encrypted_text += ch
    # FA.5c
    def show_email(self):
        print(f"CONFIDENTIAL")
        print(f"From: {self.frm}")
        print(f"To: {self.to}")
        print(f"Date: {self.date}")
        print(f"Subject: {self.subject}")
        print(f"Body: {self.body}")
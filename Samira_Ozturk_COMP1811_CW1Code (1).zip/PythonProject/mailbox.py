#################################################################################################
### COMP1811 - CW1 Outlook Simulator                                                          ###
###            confidential program                                                            ###
### Partner A:                                                                                ###
###            <Tahseen Taj>, SID<001464034-1>                              ###
### Partner B:                                                                                ###
###            <Samira Ozturk>, SID<00149407-4>                              ###
#################################################################################################

from confidential import Confidential
from mail import Mail
from personal import Personal


class MailboxAgent:
    """<This is the documentation for MailboxAgent. Complete the docstring for this class.>"""

    def __init__(self, email_data):
        # email_data= data program passes in (file of email info)
        # self._mailbox = creates private variable inside object
        # underscore for internal use
        self._mailbox = self.__gen_mailbox(email_data)  # data structure containing Mail objects DO NOT CHANGE

    # Given email_data (string containing each email on a separate line),
    # __gen_mailbox returns mailbox as a list containing received emails as Mail objects
    @classmethod  # decorator, telling pythin this method belongs to the class, not object
    def __gen_mailbox(cls, email_data):  # DO NOT CHANGE
        """ generates mailbox data structure
            :ivar: String
            :rtype: list  """
        mailbox = []  # empty list, later for Mail objects
        for e in email_data:
            msg = e.split('\n')  # split text wherever new line starts
            mailbox.append(
                Mail(msg[0].split(":")[1], msg[1].split(":")[1], msg[2].split(":")[1], msg[3].split(":")[1],
                     msg[4].split(":")[1], msg[5].split(":")[1], msg[6].split(":")[1]))
        return mailbox


# FEATURES A (Partner A)
# FA.1 retrieve email with get_email()
# Loops through Mail objects in mailbox and compares m_id with ones requested.
# Returns matching Mail and None if ID doesnt exist.
    def get_email(self, m_id):  # function inside class to find email in mailbox BY ID and return
        for mail in self._mailbox:  # looks in object inside self._mailbox list inside __gen.mailbox
            if mail.m_id == str(m_id):  # ensure comparison type
                return mail
        return None  # only if not found


# FA.3 delete email with del_email()
# search email using ID, if found it gets removed and prints confirmation.
    def del_email(self, m_id):
        for mail in self._mailbox:
            if mail.m_id == str(m_id):
                mail.tag = "bin"  # move the email to bin by changing the tag
                print(f"Email ID {m_id} moved to bin successfully.")
                return True
        # If no email with that ID was found
        else:
            print("Email not found.")
            return False


# FA.4
    def filter(self, frm):
        filtered = [mail for mail in self._mailbox if mail.frm.lower() == frm.lower()]
        # list comprehension, where sender matches frm
        # converts sender to lowercase so Email1@... matches email1@...
        if not filtered:
            print(f"No email found from {frm}.")
        else:
            for mail in filtered:
                mail.show_mail()  # display using function pretty print from A2
            return filtered  # return list for later need


# FA.5
    def sort_date(self):
        def get_date(mail):  # extract from Mail class
            return mail.date

        self._mailbox.sort(key=get_date, reverse=True)
        # use get_date todecide what to sort by
        # sorts largest to smallest (newest to oldest)
        return self._mailbox

     # FEATURES B (Partner B)
     # FB.1
     #
    def show_emails(self):
        """ showing table type format for displaying all emails as given in the coursework  """

        if not self._mailbox:
            print("No Emails")  # Display if there are no emails in mailbox
            return

            # print the header of the table as coursework
        print(f"Id: |From:               |To:                 |Date:       |Subject:      |Tag:   |Body:")

        # Print each email row
        for mail in self._mailbox:
             print(f"{mail.m_id:<3} |"
                    f"{mail.frm:<20}|"
                    f"{mail.to:<20}|"
                    f"{mail.date:<12}|"
                    f"{mail.subject:<13}|"
                    f"{mail.tag:<8}|"
                    f"{mail.body}")

        # FB.2
        #
        def mv_email(self, m_id, tag):
            """Implement the mv_email(m_id, tag) stub. Given an email ID, m_id and tag (the folder name to move
               the email to), move that email to the folder indicated in tag. To simulate moving an email to a different
               folder, replace the existing _tag value for that email with the value passed in the tag argument.  """
            # Moves an email to a new folder by updating its tag attribute.
            # Retrieve the mail for the provided mail id
            mail_found = False
            # 1. Loop through the mailbox to find the matching email ID
            # Assuming self.mailbox is the list containing all Mail objects
            for mail in self._mailbox:
                # Check if the current email's ID matches the provided m_id
                if mail.m_id == m_id:
                    # 2. Simulate moving the email by replacing the tag value
                    # Update the object's attribute directly
                    mail.tag = tag

                print(f"Successfully moved email ID {m_id} to folder: '{tag}'.")
                mail_found = True

                # Since the email is found and updated, we can stop the loop
                break

                # 3. Check if the email was found and moved
            if mail_found:
                return True
            else:
                # If the loop finished without finding a match, print an error and return False
                print(f"Error: Email ID {m_id} not found in mailbox.")
                return False

        # FB.3
        def mark(self, m_id, m_type):
            """Implement the mrk(m_id, mrk_type) stub. Given an email ID, m_id, mark that email as mark_type
               (read or flagged). This simulates an email shown as read in the mailbox or one that is flagged for follow
                up at a later time.   """

            mail_found = False
            mark_type = m_type.lower()  # standardazing the input

            for mail in self._mailbox:
                # check if the m_id provided is in the mailbox
                if mail.m_id == m_id:

                    # check if the mail is read or not
                    if mark_type == "read":
                        mail.read = True
                        print(f"Email id {mail.m_id} marked as READ")
                    # check if it is flagged or not and update it for follow up
                    elif mark_type == "flagged":
                        mail.read = True
                        print(f"EMail id {mail.m_id} marked as Flagged")

                    else:
                        print("Error, Invalid mail type. Should be 'READ' or 'FLAGGED'")
                        return False
                    mail_found == True
                    break  # end of loop

            if mail_found:
                return True
            else:
                print("Invalid Emaid ID")
                return False

        # FB.4
        #
        def find(self, date):
            """Implement the find(date) stub. Given a specific date, date as a string, return a list of all the emails
               received on that date. This simulates searching the mailbox for all emails received on a particular date.   """

            input_date = date.strip()

            # 1. Initialize an empty list to store all Mail objects that match the date.
            email_list = []

            # check if the mails are upto that date
            for mail in self._mailbox:
                # 3. Check if the input date matches the email's date attribute.
                if input_date == mail.date:
                    # 4. If a match is found, add the entire Mail object to the results list.
                    email_list.append(mail)

                    # 5. After checking all emails, check if the list of results is empty.
            if not email_list:
                print(f"No Emails found on that date: {date}")

            ## 6. Return the list of matching emails (it will be an empty list if no matches were found).
            return email_list

        # FB.5
        #
        def sort_from(self):
            """ Sorts the mailbox list in-place by the sender's email address (frm). """
            if not self._mailbox:
                print("Mailbox not empty")
                return

            # .lower(): ensures the sort is case-insensitive (A vs a)
            self._mailbox.sort(key=lambda mail: mail.frm.lower())

            print("Mailbox successfully sorted by Sender.")

# FEATURE 6 (Partners A and B)
    def add_email(self, frm, to, date, subject, tag, body):
        """
        FA.6 Add new email (group):
        - Generate a unique m_id.
        - Create the correct email object type based on tag:
            'conf'  -> Confidential
            'prsnl' -> Personal
            other   -> general Mail
        - Append the new object to the _mailbox data structure.
        """
        # FA.6
        # Generate a unique m_id
        if not self._mailbox:
            # If mailbox is empty, start IDs from "1"
            new_m_id = "1"
        else:
            # find the highest numeric m_id currently in the mailbox
            max_id = 0
            for mail in self._mailbox:
                try:
                    current_id = int(mail.m_id)  # mail.m_id is a property
                    if current_id > max_id:
                        max_id = current_id
                except ValueError:
                    # in case some m_id is not numeric, just ignore it
                    continue
                    new_m_id = str(max_id + 1)


        # normalise the tag for pattern matching
        tag_lower = tag.lower()
        # create the correct email object based on the tag
        match tag_lower:
            case "conf":
                # FA.6 create a Confidential email object, execue when tag is conf
                new_mail = Confidential(new_m_id, frm, to, date, subject, tag, body)
            case "prsnl":
                # FB.6 will execute with personal.py when tag is prsnl
                new_mail = Personal(new_m_id, frm, to, date, subject, tag, body)
            case _:
                # FA&B.6 – default email type, execute when email is neither prsnl nor conf
                new_mail = Mail(new_m_id, frm, to, date, subject, tag, body)
        # Append the new email object to the mailbox list
        self._mailbox.append(new_mail)
        return new_mail